package mood.moodmyapp.member.entity;

import lombok.*;
import mood.moodmyapp.jpaEntity.BaseTimeEntity;

import javax.persistence.*;
import java.util.Date;
@AllArgsConstructor // 생성자 추가
@NoArgsConstructor  //  기본생성자 자동 추가
@Builder
@Getter
@Setter
@Entity(name="Member") // 회원가입에 관한 entity
@Table(name="tbl_member")   //class이름과 테이블이름이 다를경우에 써주어야함.
public class Member extends BaseTimeEntity {


            @Id
            @Column(name="userId", length = 50, nullable = false)
            private String userId;  // PK값

            @Column(name="userPw", length = 50, nullable = false)
            private String userPw;      //  회원비밀번호

            @Column(name="userName", length = 20,nullable = false)
            private String userName;      //  회원이름

            @Column(name="nickName", length = 20,nullable = false)
            private String nickName;      //  회원닉네임

            @Column(name="phoneNum", length = 20,nullable = false)
            private String phoneNum;      //  회원휴대폰번호

            @Column(name="kakaoYn", length = 1,nullable = false)
            private String kakaoYn = "N";      //  카카오로그인여부

            /*@Column(name="reg_date", nullable = true)
            @Temporal(TemporalType.TIMESTAMP)
            private Date reg_date;*/ // 날짜와 시간*/


            /*@Column(name="reg_date", nullable = false)
            //@Temporal(TemporalType.TIMESTAMP)
            private LocalDateTime reg_date; // 날짜와 시간*/

/*            @PrePersist
            public void dateTime(){
                this.reg_date = LocalDateTime.now();

            }*/
            //@Column(length = 14,nullable = false)
            //private String reg_date = dateTime(dateTime);
            //private String reg_date = LocalDate.now().format(DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss"));      //  등록일

            @Column(name="term1", length = 1, nullable = false)
            private String term1 = "N";      //  약관1동의여부

            @Column(name="term2", length = 1, nullable = false)
            private String term2 = "N";      //  약관1동의여부

}

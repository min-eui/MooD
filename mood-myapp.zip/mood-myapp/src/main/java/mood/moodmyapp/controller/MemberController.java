package mood.moodmyapp.controller;

import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import lombok.RequiredArgsConstructor;
import mood.moodmyapp.dto.MemberDto;
import mood.moodmyapp.member.entity.Member;
import mood.moodmyapp.service.MemberService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping(value= "/member")
public class MemberController {

    @Autowired
    private final MemberService memberService;

    public MemberController(MemberService memberService) {

        this.memberService = memberService;
    }

    @GetMapping("/join.do")
    public String memberJoinForm(){
        return "member/joinForm";
    }


    @PostMapping("/join.do")
    public String memberJoin(Member member){

        memberService.join(member);
        return "redirect:/";
    }




}

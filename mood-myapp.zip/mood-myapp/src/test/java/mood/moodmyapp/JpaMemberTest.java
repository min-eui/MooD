package mood.moodmyapp;

import mood.moodmyapp.member.entity.Member;
import mood.moodmyapp.repository.MemberRepository;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import java.time.LocalDateTime;
import java.util.Date;

import static org.assertj.core.api.Assertions.assertThat;
@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest
public class JpaMemberTest {

    @Autowired
    MemberRepository memberRepository;

    @Test
    //회원가입
    public void  save(){

        Date date  = new Date();

        Member member = new Member();
        //1. 회원 파라미터 생성
        member = Member.builder()
                .userId("fnqlehcl11")
                .userPw("1234")
                .userName("김주현")
                .nickName("주주")
                .phoneNum("01041422557")
                .kakaoYn("N")
                .term1("Y")
                .term2("Y")
                .build();
        //2. 회원 저장
        System.out.println(">>>>>>>>> reg_date = " + date);
        memberRepository.save(member);

       /* //3. 회원조회
        Member member1 = memberRepository.findById((Long)"fnqlehcl11").get();
        assertThat(member1.getNickName()).isEqualTo("주주");*/

    }

}
